#ifndef CAMERA_HANDLER_H
#define CAMERA_HANDLER_H

#include <opencv2/opencv.hpp>
#include <opencv2/cudaimgproc.hpp>
#include <opencv2/cudaarithm.hpp>
#include <vector>
#include <string>

class CameraHandler {
public:
    CameraHandler(const std::string& devicePath = "/dev/video0");
    ~CameraHandler();

    bool initializeCamera();
    void releaseCamera();
    void getFrame(cv::Mat& frame);
    std::vector<cv::Point> getFingerTip(const cv::Mat& frame);
    //cv::cuda::GpuMat processFrame(const cv::Mat& frame);

private:
    cv::VideoCapture cap;  // 카메라 캡처 객체
    std::string devicePath;
};

#endif // CAMERA_HANDLER_H