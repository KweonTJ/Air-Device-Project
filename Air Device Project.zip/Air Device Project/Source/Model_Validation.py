import os
import cv2
import torch
import random
import numpy as np
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader, random_split
import matplotlib.pyplot as plt

# 경로 설정
train_data_path = "Archive/train"
test_data_path = "Archive/test"
save_path = "Model"
os.makedirs(save_path, exist_ok=True)

# 하이퍼파라미터 설정
img_height, img_width = 64, 64
batch_size = 40
num_epochs = 30
learning_rate = 0.001
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"사용 중인 장치 : {device}")


# 데이터셋 클래스 정의
class GestureDataset(Dataset):
    def __init__(self, data_path, img_height, img_width, augment=False):
        self.images = []
        self.labels = []
        self.img_height = img_height
        self.img_width = img_width
        self.augment = augment

        # 각 클래스 폴더에서 데이터 불러오기
        for label in range(6):  # 클래스 0~5로 가정
            folder_path = os.path.join(data_path, str(label))
            if not os.path.exists(folder_path):
                print(f"[Warning] 폴더가 없습니다: {folder_path}")
                continue
            for img_name in os.listdir(folder_path):
                img_path = os.path.join(folder_path, img_name)
                img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
                if img is None:
                    print(f"[Warning] 이미지 로드 실패: {img_path}")
                    continue
                img = cv2.resize(img, (self.img_width, self.img_height))
                self.images.append(img)
                self.labels.append(label)

        if not self.images:
            raise RuntimeError("이미지를 불러오지 못했습니다. 데이터셋 경로를 확인하세요.")

        self.images = np.array(self.images).reshape(-1, 1, self.img_height, self.img_width) / 255.0
        self.labels = np.array(self.labels)

    def augment_image(self, img):
        # 회전, 반전, 노이즈 추가 등 데이터 증강
        if random.random() > 0.5:
            img = cv2.flip(img, 1)  # 좌우 반전
        angle = random.uniform(-15, 15)
        M = cv2.getRotationMatrix2D((self.img_width // 2, self.img_height // 2), angle, 1)
        img = cv2.warpAffine(img, M, (self.img_width, self.img_height))
        return img

    def __len__(self):
        return len(self.images)

    def __getitem__(self, idx):
        img = self.images[idx]
        label = self.labels[idx]
        return torch.tensor(img, dtype=torch.float32), torch.tensor(label, dtype=torch.long)


# 모델 정의
class GestureModel(nn.Module):
    # def __init__(self, num_classes):
    #     super(GestureModel, self).__init__()
    #     self.flatten = nn.Flatten()
    #     self.fc1 = nn.Linear(img_height * img_width, 128)
    #     self.fc2 = nn.Linear(128, 64)
    #     self.fc3 = nn.Linear(64, num_classes)
    # def forward(self, x):
    #     x = self.flatten(x)
    #     x = torch.relu(self.fc1(x))
    #     x = torch.relu(self.fc2(x))
    #     x = self.fc3(x)
    #     return x
    def __init__(self, num_classes):
        super(GestureModel, self).__init__()
        self.conv1 = nn.Conv2d(1, 32, kernel_size=3, stride=1, padding=1)
        self.pool = nn.MaxPool2d(kernel_size=2, stride=2)
        self.conv2 = nn.Conv2d(32, 64, kernel_size=3, stride=1, padding=1)
        self.fc1 = nn.Linear(64 * (img_height // 4) * (img_width // 4), 128)
        self.dropout = nn.Dropout(0.5)
        self.fc2 = nn.Linear(128, num_classes)
    
    def forward(self, x):
        x = self.pool(torch.relu(self.conv1(x)))
        x = self.pool(torch.relu(self.conv2(x)))
        x = x.view(x.size(0), -1)
        x = torch.relu(self.fc1(x))
        x = self.fc2(x)
        return x


# 데이터 로드
train_dataset = GestureDataset(train_data_path, img_height, img_width)
test_dataset = GestureDataset(test_data_path, img_height, img_width)

# 데이터 분할 (훈련 데이터와 검증 데이터로 나눔)
val_ratio = 0.2
val_size = int(len(train_dataset) * val_ratio)
train_size = len(train_dataset) - val_size
train_dataset, val_dataset = random_split(train_dataset, [train_size, val_size])

# DataLoader 생성
train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)
test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

# 모델 초기화
model = GestureModel(num_classes=6).to(device)

# 손실 함수와 옵티마이저 설정
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=learning_rate)
schedule = optim.lr_scheduler.StepLR(optimizer, step_size=3, gamma=0.5)


# 학습 및 검증 함수
def train_and_validate():
    train_losses, val_losses = [], []
    train_accuracies, val_accuracies = [], []

    for epoch in range(num_epochs):
        # === 훈련 단계 ===
        model.train()
        train_loss, correct, total = 0, 0, 0
        for images, labels in train_loader:
            images, labels = images.to(device), labels.to(device)

            # 순전파
            outputs = model(images)
            loss = criterion(outputs, labels)

            # 역전파 및 최적화
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            train_loss += loss.item()
            _, predicted = torch.max(outputs, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()

        train_losses.append(train_loss / len(train_loader))
        train_accuracies.append(correct / total)

        # === 검증 단계 ===
        model.eval()
        val_loss, correct, total = 0, 0, 0
        with torch.no_grad():
            for images, labels in val_loader:
                images, labels = images.to(device), labels.to(device)

                # 순전파
                outputs = model(images)
                loss = criterion(outputs, labels)

                val_loss += loss.item()
                _, predicted = torch.max(outputs, 1)
                total += labels.size(0)
                correct += (predicted == labels).sum().item()

        val_losses.append(val_loss / len(val_loader))
        val_accuracies.append(correct / total)

        print(f"Epoch [{epoch+1}/{num_epochs}], Train Loss: {train_losses[-1]:.4f}, "
              f"Train Acc: {train_accuracies[-1]:.4f}, Val Loss: {val_losses[-1]:.4f}, Val Acc: {val_accuracies[-1]:.4f}")

    return train_losses, train_accuracies, val_losses, val_accuracies


# 테스트 함수
def test_model():
    model.eval()
    correct, total = 0, 0
    with torch.no_grad():
        for images, labels in test_loader:
            images, labels = images.to(device), labels.to(device)
            outputs = model(images)
            _, predicted = torch.max(outputs, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()
    accuracy = correct / total * 100
    print(f"테스트 정확도: {accuracy:.2f}%")
    return accuracy


# 그래프 그리기
def plot_metrics(train_losses, train_accuracies, val_losses, val_accuracies):
    epochs = range(1, num_epochs + 1)

    # 정확도 그래프
    plt.figure(figsize=(14, 6))
    plt.subplot(1, 2, 1)
    plt.plot(epochs, train_accuracies, label='Train Accuracy')
    plt.plot(epochs, val_accuracies, label='Validation Accuracy')
    plt.title('Accuracy')
    plt.xlabel('Epoch')
    plt.ylabel('Accuracy')
    plt.legend()

    # 손실 그래프
    plt.subplot(1, 2, 2)
    plt.plot(epochs, train_losses, label='Train Loss')
    plt.plot(epochs, val_losses, label='Validation Loss')
    plt.title('Loss')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.legend()

    # 레이아웃 및 저장
    plt.tight_layout()
    graph_path = os.path.join(save_path, "training_validation_graph.png")
    plt.savefig(graph_path)
    print(f"그래프가 {graph_path}에 저장되었습니다.")

    # plt.tight_layout()
    plt.show()


# 학습 및 평가
train_losses, train_accuracies, val_losses, val_accuracies = train_and_validate()
plot_metrics(train_losses, train_accuracies, val_losses, val_accuracies)
test_accuracy = test_model()

# 모델 저장
model.to('cpu')
torch.save(model.state_dict(), os.path.join(save_path, "gesture_model.pth"))
scripted_model = torch.jit.script(model)
scripted_model.save(os.path.join(save_path, "gesture_model_cpu.pt"))
print("모델 저장 완료!")
