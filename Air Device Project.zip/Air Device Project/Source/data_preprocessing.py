import os
import cv2
import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader, random_split

# 데이터 폴더 경로
DATA_PATH = 'Archive/train'
GESTURE_FOLDERS = ['0','1', '2', '3', '4', '5']

# 전처리 및 학습 파라미터
IMG_SIZE = 64  # 이미지 크기 조정 (예: 64x64)
LABELS = {
    '0': 0,  # 손가락 0개
    '1': 1,  # 손가락 1개
    '2': 2,  # 손가락 2개
    '3': 3,  # 손가락 3개
    '4': 4,  # 손가락 4개
    '5': 5   # 손가락 5개
}
BATCH_SIZE = 32
SEED = 42
PROCESSED_DATA_PATH = './processed_data' # 전처리 데이터 저장 경로

# PyTorch 데이터셋 클래스 정의
class GestureDataset(Dataset):
    def __init__(self, data_path, gesture_folders, labels, img_size):
        self.data = []
        self.targets = []
        self.img_size = img_size
        
        for folder in gesture_folders:
            label = labels[folder]
            folder_path = os.path.join(data_path, folder)
            if not os.path.exists(folder_path):
                print(f"Warning: Folder {folder_path} does not exist")
                continue

            for filename in os.listdir(folder_path):
                file_path = os.path.join(folder_path, filename)
                image = cv2.imread(file_path, cv2.IMREAD_GRAYSCALE)  # 이미지를 흑백으로 불러오기
                if image is None:
                    print(f"Warning: Could not read image {file_path}")
                    continue

                image = cv2.resize(image, (img_size, img_size))      # 이미지 크기 조정
                image = image / 255.0                               # 정규화 (0~1 범위)
                
                self.data.append(image)
                self.targets.append(label)
        
        self.data = np.array(self.data).reshape(-1, 1, img_size, img_size).astype(np.float32)
        self.targets = np.array(self.targets).astype(np.int64)

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return torch.tensor(self.data[idx]), torch.tensor(self.targets[idx])

# 데이터셋을 준비하는 함수
def prepare_datasets(data_path, gesture_folders, labels, img_size, batch_size, seed):
    dataset = GestureDataset(data_path, gesture_folders, labels, img_size)

    train_size = int(0.8 * len(dataset))
    test_size = len(dataset) - train_size
    train_dataset, test_dataset = random_split(dataset, [train_size, test_size], generator=torch.Generator().manual_seed(SEED))
    
    train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True)
    test_loader = DataLoader(test_dataset, batch_size=BATCH_SIZE, shuffle=False)
    
    return train_loader, test_loader

# 데이터셋 저장 함수
def save_datasets(train_loader, test_loader, save_path):
    os.makedirs('save_path', exist_ok=True)

    # train 데이터 저장
    torch.save(train_loader, os.path.join(save_path, 'train_dataset.pt'))
    torch.save(test_loader, os.path.join(save_path, 'train_dataset.pt'))
    print("Datasets saved successfully at:", save_path)

if __name__ == '__main__':
    train_loader, test_loader = prepare_datasets(DATA_PATH, GESTURE_FOLDERS, LABELS, IMG_SIZE, BATCH_SIZE, SEED)
    save_datasets(train_loader, test_loader, PROCESSED_DATA_PATH)
