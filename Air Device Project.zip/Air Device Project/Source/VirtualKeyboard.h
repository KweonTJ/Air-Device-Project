#ifndef VIRTUALKEYBOARD_H
#define VIRTUALKEYBOARD_H

#include <opencv2/opencv.hpp>
#include <vector>
#include <string>

class VirtualKeyboard {
private:
    std::string currentText;       // 현재 입력된 텍스트
    cv::Mat keyboardImage;         // 키보드 이미지
    bool isVisible;
    int keyWidth;
    int keyHeight;

public:
    VirtualKeyboard();

    void simulateKeyPress(char key);       // 키 입력 처리
    void clearText();                      // 입력 텍스트 초기화
    void show();
    void hide();
    void showKeyboard(cv::Mat& frame);     // 키보드 시각화
    void hideKeyboard();                   // 키보드 숨김
    void loadKeyboardImage(const std::string& imagePath); // 키보드 이미지 로드
    char mapToKey(const cv::Point& fingerTip); // 손가락 좌표를 키로 매핑
};

#endif
