#include "VirtualKeyboard.h"
#include <opencv2/opencv.hpp>

VirtualKeyboard::VirtualKeyboard() : currentText("") {
    keyWidth = 592 / 10;
    keyHeight = 220 / 5;
    // isVisible = false;
}

void VirtualKeyboard::simulateKeyPress(char key) {
    if (key != '\0') {
        currentText += key;

        // 스페이스 바와 엔터 키 처리
        if (key == ' ') {
            std::cout << "[Keyboard] Space pressed.\n";
        } else if (key == '\n') {
            std::cout << "[Keyboard] Enter pressed.\n";
        } else {
            std::cout << "[Keyboard] Key pressed: " << key << "\n";
        }

        std::cout << "Current Text: " << currentText << "\n";
    }
}

void VirtualKeyboard::clearText() {
    currentText = "";
    std::cout << "[Keyboard] Text cleared.\n";
}

void VirtualKeyboard::show() {
    isVisible = true;
    std::cout << "[Keyboard] Keyboard is now visible.\n";
}

void VirtualKeyboard::hide() {
    isVisible = false;
    std::cout << "[Keyboard] Keyboard is now hidden.\n";
}

void VirtualKeyboard::showKeyboard(cv::Mat& frame) {
    if (!isVisible) return;

    if (!keyboardImage.empty()) {
        int xOffset = (frame.cols - keyboardImage.cols) / 2;
        int yOffset = frame.rows - keyboardImage.rows;

        // 화면 하단에 키보드 이미지 오버레이
        cv::Rect roi(cv::Point(xOffset, yOffset), keyboardImage.size());
        keyboardImage.copyTo(frame(roi));
    }

    // 현재 입력된 텍스트 표시
    cv::putText(frame, "Current Text: " + currentText, 
                cv::Point(10, frame.rows - keyboardImage.rows - 10),
                cv::FONT_HERSHEY_SIMPLEX, 1, cv::Scalar(0, 255, 0), 2);
}

void VirtualKeyboard::hideKeyboard() {
    isVisible = false;
    std::cout << "[Keyboard] Keyboard deactivated.\n";
}

void VirtualKeyboard::loadKeyboardImage(const std::string& imagePath) {
    keyboardImage = cv::imread(imagePath, cv::IMREAD_UNCHANGED);
    if (keyboardImage.empty()) {
        std::cerr << "[Keyboard] Failed to load keyboard image from " << imagePath << std::endl;
    } else {
        std::cout << "[Keyboard] Keyboard image loaded successfully." << imagePath << std::endl;
    }
}

char VirtualKeyboard::mapToKey(const cv::Point& fingerTip) {
    int col = fingerTip.x / keyWidth;        // 손가락 x좌표를 열로 변환
    int row = fingerTip.y / keyHeight;       // 손가락 y좌표를 줄로 변환

    // QWERTY 키보드 레이아웃에 스페이스 바와 엔터 키 추가
    const std::vector<std::string> layout = {
        "1234567890"
        "QWERTYUIOP", // 첫 번째 줄
        "ASDFGHJKL",  // 두 번째 줄
        "ZXCVBNM ",   // 세 번째 줄, 스페이스 바 시작
        "     SPACE    ENTER" // 네 번째 줄, 스페이스 바와 엔터
    };

    // 좌표가 유효한 영역에 있는지 확인
    if (row >= 0 && row < layout.size() && col >= 0 && col < layout[row].size()) {
        char key = layout[row][col];
        // 스페이스와 엔터 매핑 처리
        if (key == 'S') return ' ';   // SPACE 키 영역을 공백으로 매핑
        if (key == 'E') return '\n'; // ENTER 키 영역을 줄 바꿈으로 매핑
        return key;                  // 일반 키 반환
    }

    return '\0'; // 매핑 실패 시 반환
}