#ifndef VIRTUAL_DEVICE_MANAGER_H
#define VIRTUAL_DEVICE_MANAGER_H

enum class DeviceState { MouseActive, KeyboardActive };

class VirtualDeviceManager {
private:
    DeviceState currentState;

public:
    VirtualDeviceManager();
    void setState(DeviceState state);
    DeviceState getState() const;
    bool isKeyboardActive() const;
};

#endif
