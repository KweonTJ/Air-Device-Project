#include "VirtualDeviceManager.h"

VirtualDeviceManager::VirtualDeviceManager() : currentState(DeviceState::MouseActive) {}

void VirtualDeviceManager::setState(DeviceState state) {
    currentState = state;
}

DeviceState VirtualDeviceManager::getState() const {
    return currentState;
}

bool VirtualDeviceManager::isKeyboardActive() const {
    return currentState == DeviceState::KeyboardActive;
}
