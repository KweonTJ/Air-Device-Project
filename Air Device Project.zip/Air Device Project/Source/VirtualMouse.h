#ifndef VIRTUAL_MOUSE_H
#define VIRTUAL_MOUSE_H

#include <X11/Xlib.h>
#include <iostream>

class VirtualMouse {
public:
    void moveMouse(int x, int y);
    void leftClick();
    void upDrag();
    void downDrag();
    void deactivate();
    void activate();

private:
    Display* display;
    int frameWidth = 320;
    int frameHeight = 240;
    bool drageActive = false;
};

#endif // VIRTUAL_MOUSE_H
