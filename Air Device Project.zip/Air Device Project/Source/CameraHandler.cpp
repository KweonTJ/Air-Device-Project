#include "CameraHandler.h"
#include <iostream>

CameraHandler::CameraHandler(const std::string& devicePath) : devicePath(devicePath) {}

CameraHandler::~CameraHandler() {
    releaseCamera();
}

bool CameraHandler::initializeCamera() {
    cap.open(devicePath, cv::CAP_V4L2);  // 디바이스 경로로 카메라 열기
    if (!cap.isOpened()) {
        std::cerr << "Error: Cannot open video device " << devicePath << std::endl;
        return false;
    }

    cap.set(cv::CAP_PROP_FRAME_WIDTH, 320);  // 너비를 320으로 설정
    cap.set(cv::CAP_PROP_FRAME_HEIGHT, 240); // 높이를 240으로 설정
    cap.set(cv::CAP_PROP_FPS, 15);           // 프레임 속도를 15FPS로 설정

    std::cout << "Video device " << devicePath << " successfully opened." << std::endl;
    return true;
}

void CameraHandler::releaseCamera() {
    if (cap.isOpened()) {
        cap.release();
        std::cout << "Camera released.\n";
    }
}

void CameraHandler::getFrame(cv::Mat& frame) {
    if (cap.isOpened()) {
        cap >> frame;
        if (frame.empty()) {
            std::cerr << "Error: Captured empty frame.\n";
        }
    } else {
        std::cerr << "Error: Camera is not initialized.\n";
    }
}

std::vector<cv::Point> CameraHandler::getFingerTip(const cv::Mat& frame) {
    cv::Mat grayFrame, blurredFrame, binaryFrame;
    std::vector<cv::Point> fingerTips;

    // 이미지 전처리
    cv::cvtColor(frame, grayFrame, cv::COLOR_BGR2GRAY);
    cv::GaussianBlur(grayFrame, blurredFrame, cv::Size(5, 5), 0);
    cv::threshold(blurredFrame, binaryFrame, 60, 255, cv::THRESH_BINARY_INV);

    // 컨투어 검출
    std::vector<std::vector<cv::Point>> contours;
    cv::findContours(binaryFrame, contours, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);

    // 컨투어에서 중심점 추출
    for (const auto& contour : contours) {
        cv::Rect boundingBox = cv::boundingRect(contour);
        fingerTips.push_back((boundingBox.br() + boundingBox.tl()) * 0.5); // 중심점
    }

    return fingerTips;
}
