#include <iostream>
#include <opencv2/opencv.hpp>
#include "CameraHandler.h"
#include "GestureRecognition.h"
#include "VirtualKeyboard.h"
#include "VirtualMouse.h"
#include <filesystem>
#ifndef MODEL_PATH
#endif

int main() {
    // 초기화
    std::cout << "Initializing Air Device Project...\n";
    std::string model_path = MODEL_PATH;

    // 모델 파일 존재 여부 확인
    if (!std::filesystem::exists(model_path)) {
        std::cerr << "모델 파일이 존재하지 않습니다: " << model_path << std::endl;
        return -1;
    }

    // 객체 생성
    CameraHandler cameraHandler;
    GestureRecognition gestureRecognition(model_path);
    VirtualKeyboard virtualKeyboard;
    VirtualMouse virtualMouse;

    // 모델 로드
    torch::jit::script::Module model;
    try {
        model = torch::jit::load(model_path);
        std::cout << "모델 로드 성공: " << model_path << std::endl;
    } catch (const c10::Error& e) {
        std::cerr << "모델 로드 실패: " << e.what() << std::endl;
        return -1;
    }

    // 카메라 초기화
    if (!cameraHandler.initializeCamera()) {
        std::cerr << "Failed to initialize camera.\n";
        return -1;
    }

    cv::setNumThreads(0);
    at::set_num_threads(1);

    cv::Mat frame;
    while (true) {
        cameraHandler.getFrame(frame);
        if (frame.empty()) {
            std::cerr << "[Main] Empty frame captured.\n";
            frame = cv::Mat::zeros(480, 640, CV_8UC3);
        }

        try {
            int gesture = gestureRecognition.processedFrame(frame);
            if (gesture == -1) continue; // 에러 발생 시 루프 재시작
        } catch (const std::exception& e) {
            std::cerr << "[Main] Frame processing error: " << e.what() << std::endl;
        }

        cv::imshow("Air Device Project", frame);
        if (cv::waitKey(1) == 27) break; // ESC 키로 종료
    }

    // 메인 루프
    while (true) {
        // 프레임 캡처
        cameraHandler.getFrame(frame);
        if (frame.empty()) {
            std::cerr << "Empty frame captured. Exiting loop.\n";
            break;
        }

        try {
            // 제스처 인식 및 처리
            int gesture = gestureRecognition.processedFrame(frame);

            // 제스처 결과에 따라 동작 수행
            switch (gesture) {
                case 0:
                    std::cout << "[Main] Gesture: Deactivate Keyboard\n";
                    virtualKeyboard.hide();
                    virtualMouse.activate();
                    break;
                case 1:
                    std::cout << "[Main] Gesture: Move Mouse\n";
                    virtualMouse.moveMouse(100,200);
                    break;
                case 2:
                    std::cout << "[Main] Gesture: Left Click\n";
                    virtualMouse.leftClick();
                    break;
                case 3:
                    std::cout << "[Main] Gesture: Drag up\n";
                    virtualMouse.upDrag();
                    break;
                case 4:
                    std::cout << "[Main] Gesture: Drag down";
                    virtualMouse.downDrag();
                case 5:
                    std::cout << "[Main] Gesture: Activate Keyboard\n";
                    virtualKeyboard.show();
                    virtualMouse.deactivate();
                    break;
                default:
                    // std::cout << "[Main] Unrecognized Gesture\n";
                    break;
            }

            // 키보드가 활성 상태라면 화면에 표시
            if (gestureRecognition.isKeyboardActive()) {
                virtualKeyboard.showKeyboard(frame);
            }

        } catch (const std::exception& e) {
            std::cerr << "Error processing frame: " << e.what() << std::endl;
        }

        // 화면 출력
        cv::imshow("Air Device Project", frame);

        // ESC 키로 종료
        if (cv::waitKey(1) == 27) {
            std::cout << "[Info] Exiting main loop.\n";
            break;
        }
    }

    // 리소스 해제
    cameraHandler.releaseCamera();
    std::cout << "Resources released. Program terminated.\n";

    return 0;
}
