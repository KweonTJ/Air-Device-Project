#include "VirtualMouse.h"
#include <X11/extensions/XTest.h>
#include <X11/Xlib.h>
#include <iostream>
#include <unistd.h>
#include <algorithm>
#define GET_DISPLAY() displayManager.get()

namespace {
// X11 디스플레이를 관리하는 유틸리티 클래스
class DisplayManager {
public:
    DisplayManager() {
        display = XOpenDisplay(NULL);
        if (!display) {
            std::cerr << "[Error] Failed to open X display.\n";
        }
    }

    ~DisplayManager() {
        if (display) {
            XCloseDisplay(display);
            std::cout << "[DisplayManager] Display closed.\n";
        }
    }

    Display* get() const { return display; }

private:
    Display* display;
};

inline int clampValue(int value, int minVal, int maxVal) {
    return std::max(minVal, std::min(value, maxVal));
}

static DisplayManager displayManager;
}

void VirtualMouse::activate() {
    std::cout << "[VirtualMouse] Activated." << std::endl;
}

void VirtualMouse::moveMouse(int x, int y) {
    Display* display = displayManager.get();
    if (!display) return;

    int screenWidth = DisplayWidth(display, DefaultScreen(display));
    int screenHeight = DisplayHeight(display, DefaultScreen(display));

    // 상대 좌표를 절대 좌표로 변환
    int mappedX = clampValue(x * screenWidth / frameWidth, 0, screenWidth - 1);
    int mappedY = clampValue(y * screenHeight / frameHeight, 0, screenHeight - 1);

    // 커서 이동
    XWarpPointer(display, None, DefaultRootWindow(display), 0, 0, 0, 0, mappedX, mappedY);
    XFlush(display);
    std::cout << "[Mouse] Cursor moved to: " << mappedX << ", " << mappedY << std::endl;

    sleep(1);
}

void VirtualMouse::leftClick() {
    Display* display = displayManager.get();
    if (!display) return;

    // Left button press and release twice
    XTestFakeButtonEvent(display, 1, True, 0);  // Press
    XTestFakeButtonEvent(display, 1, False, 0); // Release
    XFlush(display);
    // XCloseDisplay(display);
    std::cout << "[Mouse] click performed.\n";
    sleep(1);
}

// void VirtualMouse::tabSwitch() {
//     Display* display = displayManager.get();
//     if (!display) return;
//     // Simulate Alt+Tab key press and release
//     KeyCode altKey = XKeysymToKeycode(display, XStringToKeysym("Alt_L"));
//     KeyCode tabKey = XKeysymToKeycode(display, XStringToKeysym("Tab"));
//     if (altKey && tabKey) {
//         XTestFakeKeyEvent(display, altKey, True, 0);  // Alt press
//         XTestFakeKeyEvent(display, tabKey, True, 0);  // Tab press
//         XTestFakeKeyEvent(display, tabKey, False, 0); // Tab release
//         XTestFakeKeyEvent(display, altKey, False, 0); // Alt release
//         XFlush(display);
//         std::cout << "[Mouse] Tab switch performed.\n";
//     } else {
//         std::cerr << "[Error] Failed to retrieve keycodes for Alt or Tab.\n";
//     }
// }

void VirtualMouse::upDrag() {
    Display* display = displayManager.get();
    if (!display) return;

    XTestFakeButtonEvent(display, 1, True, 0); // Left button press
    XFlush(display);
    std::cout << "[Mouse] Drag up.\n";
    sleep(1);
}

void VirtualMouse::downDrag() {
    Display* display = displayManager.get();
    if (!display) return;

    XTestFakeButtonEvent(display, 1, False, 0); // Left button release
    XFlush(display);
    std::cout << "[Mouse] Drag down.\n";
    sleep(1);
}

void VirtualMouse::deactivate() {
    std::cout << "[Mouse] Mouse functionality deactivated.\n";
}