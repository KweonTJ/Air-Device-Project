#ifndef GESTURE_RECOGNITION_H
#define GESTURE_RECOGNITION_H

#include <string>
#include <torch/script.h>
#include <torch/torch.h>
#include <opencv2/opencv.hpp>
#include "VirtualKeyboard.h"
#include "VirtualMouse.h"

class GestureRecognition {
private:
    torch::jit::script::Module model; // PyTorch 모델 객체
    bool modelLoaded;
    bool keyboardActive;
    std::chrono::steady_clock::time_point lastActivityTime;
    VirtualKeyboard virtualKeyboard;
    VirtualMouse virtualMouse;

public:
    GestureRecognition(const std::string& modelPath);
    void loadModel(const std::string& modelPath);
    int processedFrame(const cv::Mat& frame);
    int detectFingers(const cv::Mat& frame);
    void handleGesture(int fingerCount);
    void resetInactivityTimer();
    bool isKeyboardActive() const { return keyboardActive; }
};

#endif
