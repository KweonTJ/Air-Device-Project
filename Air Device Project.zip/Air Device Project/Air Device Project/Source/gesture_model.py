import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import cv2
import os
import numpy as np

# 데이터 경로와 제스처 분류 매핑
data_path = "Archive/train"
save_path = "Model"
os.makedirs(save_path, exist_ok=True)
img_height, img_width = 64, 64
batch_size = 16
num_epochs = 10
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


# 데이터셋 클래스 정의
class GestureDataset(Dataset):
    def __init__(self, data_path, img_height, img_width):
        self.images = []
        self.labels = []
        self.img_height = img_height
        self.img_width = img_width

        # 폴더 이름을 라벨로 사용
        for label in range(6):
            folder_path = os.path.join(data_path, str(label))
            if not os.path.exists(folder_path):
                print(f"[Warning] 폴더가 없습니다 : {folder_path}")
                continue
            for img_name in os.listdir(folder_path):
                img_path = os.path.join(folder_path, img_name)
                img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
                if img is None:
                    print (f"[Warning] 이미지 로드 실패: {img_path}")
                    continue
                img = cv2.resize(img, (self.img_width, self.img_height))
                self.images.append(img)
                self.labels.append(label)

        if not self.images:
            raise RuntimeError("이미지를 불러오지 못했습니다. 데이터셋 경로를 확인하세요.")

        self.images = np.array(self.images).reshape(-1, 1, self.img_height, self.img_width) / 255.0
        self.labels = np.array(self.labels)

    def __len__(self):
        return len(self.images)

    def __getitem__(self, idx):
        img = self.images[idx]
        label = self.labels[idx]
        return torch.tensor(img, dtype=torch.float32), torch.tensor(label, dtype=torch.long)


# 모델 정의
class GestureModel(nn.Module):
    def __init__(self, num_classes):
        super(GestureModel, self).__init__()
        self.flatten = nn.Flatten()
        self.fc1 = nn.Linear(img_height * img_width, 64)
        self.fc2 = nn.Linear(64, 32)
        self.fc3 = nn.Linear(32, num_classes)

    def forward(self, x):
        x = self.flatten(x)
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        x = self.fc3(x)
        return x


# 데이터 로드
try:
    dataset = GestureDataset(data_path, img_height, img_width)
except RuntimeError as e:
    print(f"[Error] 데이터셋 로드 실패: {e}")
    exit()

dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True)

# 모델 생성
model = GestureModel(num_classes=6).to(device)

# 손실 함수 및 옵티마이저 정의
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

# 모델 학습
model.train()
for epoch in range(num_epochs):
    epoch_loss = 0
    for images, labels in dataloader:
        images, labels = images.to(device), labels.to(device)

        # 순전파
        outputs = model(images)
        loss = criterion(outputs, labels)

        # 역전파 및 최적화
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        epoch_loss += loss.item()
    print(f"Epoch [{epoch + 1}/{num_epochs}], Loss: {epoch_loss / len(dataloader):.4f}")

# # 모델 저장
# torch.save(model.state_dict(), os.path.join(save_path, "gesture_model.pth"))
# print(f"Pytorch 모델 저장 완료: {os.path.join(save_path, 'gesture_model.pth')}")

# # TorchScritp 형식 모델
# scripted_model = torch.jit.script(model)
# scripted_model.save(os.path.join(save_path, "gesture_model.pt"))
# print(f"모델 저장 완료: {os.path.join(save_path, 'gesture_model.pt')}")

# 모델 저장
scripted_model = torch.jit.script(model.to('cpu'))
scripted_model.save(os.path.join(save_path, "gesture_model_cpu.pt"))
print(f"모델 저장 완료: {os.path.join(save_path, 'gesture_model_cpu.pt')}")

# 학습된 상태 모델 저장
pth_model_path = os.path.join(save_path, "gesture_model.pth")
torch.save(model.state_dict(), pth_model_path)
print(f"PyTorch 모델 저장 완료: {pth_model_path}")

# C++ 코드 실행을 위한 트리거 파일 생성\
print("모델 학습 및 저장 완료. C++ 코드 실행 준비 완료.")
