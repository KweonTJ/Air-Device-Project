#include "GestureRecognition.h"
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
#include <chrono>
#include <filesystem>
#include <unistd.h>

// 생성자 : 모델 경로 초기화
GestureRecognition::GestureRecognition(const std::string& modelPath)
    : modelLoaded(false), keyboardActive(false), lastActivityTime(std::chrono::steady_clock::now()) {
    try {
        loadModel(modelPath);
    } catch (const std::runtime_error& e) {
        std::cerr << "[ERROR] " << e.what() << std::endl;
    }
}


void GestureRecognition::loadModel(const std::string& modelPath) {
    try {
        std::filesystem::path path(modelPath);
        if (!path.is_absolute()) {
            path = std::filesystem::current_path() / path; // 절대 경로로 변환
        }

        if (!std::filesystem::exists(modelPath)) {
            throw std::runtime_error("Error: 모델 파일이 존재하지 않습니다: " + modelPath);
        }

        std::cout << "Attempting to load model from: " << modelPath << std::endl;
        model = torch::jit::load(modelPath);
        std::cout<< "모델 로드 성공: " << modelPath << std::endl;
        modelLoaded = true;
    } catch (const c10::Error& e) {
        std::cerr << "모델 로드 실패: " << modelPath << std::endl;
        std::cerr << e.what() << std::endl;
        throw;
    }
}

// 손가락 감지 함수 
int GestureRecognition::detectFingers(const cv::Mat &frame) {
    if (!modelLoaded) {
        throw std::runtime_error("모델이 로드되지 않았습니다.");
    }

    // === OpenCV 손 윤곽선 검출 ===
    cv::Mat gray, blurred, thresholded;
    cv::cvtColor(frame, gray, cv::COLOR_BGR2GRAY); // 그레이스케일 변환
    cv::GaussianBlur(gray, blurred, cv::Size(5, 5), 0); // 블러링
    cv::threshold(blurred, thresholded, 60, 255, cv::THRESH_BINARY_INV); // 이진화

    // 윤곽선 검출
    std::vector<std::vector<cv::Point>> contours;
    std::vector<cv::Vec4i> hierarchy;
    cv::findContours(thresholded, contours, hierarchy, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);

    if (contours.empty()) {
        std::cerr << "[Error] 손 윤곽선을 찾을 수 없습니다.\n";
        return 0;
    }

    // 가장 큰 윤곽선 선택 (손으로 추정)
    size_t largestContourIndex = 0;
    double maxArea = 0;
    for (size_t i = 0; i < contours.size(); ++i) {
        double area = cv::contourArea(contours[i]);
        if (area > maxArea) {
            maxArea = area;
            largestContourIndex = i;
        }
    }
    std::vector<cv::Point> handContour = contours[largestContourIndex];

    // 볼록 껍질(convex hull)과 결함 계산
    std::vector<int> hullIndices;
    std::vector<cv::Vec4i> defects;
    cv::convexHull(handContour, hullIndices, true);
    if (hullIndices.size() > 3) {
        cv::convexityDefects(handContour, hullIndices, defects);
    }

    // OpenCV로 손가락 개수 추정
    int fingerCount = 0;
    if (!defects.empty()) {
        for (const auto& defect : defects) {
            cv::Point start = handContour[defect[0]];
            cv::Point end = handContour[defect[1]];
            cv::Point far = handContour[defect[2]];

            // 손가락 조건: 시작-끝 거리와 시작-결함 거리 기준
            double angle = std::atan2(start.y - far.y, start.x - far.x) -
                           std::atan2(end.y - far.y, end.x - far.x);
            if (angle < CV_PI / 2) {
                fingerCount++;
            }
        }
    }

    // === PyTorch 모델 기반 손가락 개수 확인 ===
    cv::Mat resized;
    cv::resize(gray, resized, cv::Size(64, 64));
    resized.convertTo(resized, CV_32F, 1.0 / 255.0); // 정규화

    auto inputTensor = torch::from_blob(
        resized.data, {1, 1, resized.rows, resized.cols}, torch::kFloat32);
    inputTensor = inputTensor.to(torch::kCPU);

    auto output = model.forward({inputTensor}).toTensor();
    int predictedFingerCount = output.argmax(1).item<int>();

    // std::cout << "OpenCV 추정 손가락: " << fingerCount
    //           << ", PyTorch 예측 손가락: " << predictedFingerCount << std::endl;

    // OpenCV와 PyTorch 결과를 결합해 최종 손가락 개수 반환
    return std::max(fingerCount, predictedFingerCount);

    // // 입력 데이터 전처리
    // cv::Mat resized;
    // cv::resize(frame, resized, cv::Size(64, 64));
    // resized.convertTo(resized, CV_32F, 1.0 / 255.0);  // Normalize
    // auto inputTensor = torch::from_blob(
    //     resized.data, {1, 1, resized.rows, resized.cols}, torch::kFloat32);
    // if (inputTensor.sizes() != torch::IntArrayRef({1, 1, 64, 64})) {
    //     throw std::runtime_error("입력 텐서의 크기가 올바르지 않습니다.");
    // }
    // // 추론 수행
    // inputTensor = inputTensor.to(torch::kCPU);
    // auto output = model.forward({inputTensor}).toTensor();
    // auto prediction = output.argmax(1).item<int>();
    // std::cout << "Predicted fingers: " << prediction << std::endl;
    // //return detectFingers(frame);
    // return prediction;
}

// 프레임 처리 함수 
int GestureRecognition::processedFrame(const cv::Mat &frame) {
    try{
        int fingerCount = detectFingers(frame); // 손가락 감지
        handleGesture(fingerCount); // 감지 손가락 제스처 처리
        return fingerCount;
    } catch (const std::exception& e) {
        std::cerr << "Error during frame processing: " << e.what() << std::endl;
        return -1;
    }
}

// 제스처 처리함수 
void GestureRecognition::handleGesture(int fingerCount) {
    resetInactivityTimer();

    int sleepDuration = 0;

    if (keyboardActive) {
        if (fingerCount !=5) {
            std::cout << "Virtual keyborad is active. Igonring othre gestures.\n";
        }
        return;
    }

    switch (fingerCount) { // 손가락 갯수 변경시 감지지, loop? 슬릿 1초에 1번씩 카메라 인식하게
        case 0:  // 손가락 0개: 가상 키보드 종료
            virtualKeyboard.hide();
            virtualMouse.activate();
            keyboardActive = false;
            std::cout << "Virtual keyboard deactivated due to fist gesture (0 fingers).\n";
            sleepDuration = 0;
            break;
        case 1:  // 손가락 1개: 마우스 이동
            virtualMouse.moveMouse(100, 200);
            std::cout << "Gesture: Mouse move.\n";
            sleepDuration = 1;
            break;
        case 2:  // 손가락 2개: 더블 클릭
            virtualMouse.leftClick();
            std::cout << "Gesture: Left click.\n";
            sleepDuration = 1;
            break;
        case 3:  // 손가락 3개: 드래그 동작
            virtualMouse.upDrag();
            std::cout << "Gesture: Drag up.\n";
            sleepDuration = 1;
            break;
        case 4:
            virtualMouse.downDrag();
            std::cout << "Gesture: Drag down.\n";
            sleepDuration = 1;
            break;
        // case 5: { // 손가락 5개: 키보드 이미지 띄우기
        //     const std::string keyboardImagePath = "/Resources/keyboard.png"; // 키보드 이미지 경로
        //     cv::Mat keyboardImage = cv::imread(keyboardImagePath, cv::IMREAD_COLOR);

        //     if (keyboardImage.empty()) {
        //         std::cerr << "[Error] Failed to load keyboard image from: " << keyboardImagePath << std::endl;
        //     } else {
        //         cv::imshow("Virtual Keyboard", keyboardImage);
        //         std::cout << "Gesture: Virtual keyboard activated.\n";
        //     }

        //     // 키보드 활성화 상태로 설정
        //     keyboardActive = true;
        //     sleepDuration = 1;
        //     break;
        // }
        default:
            // std::cout << "Unrecognized gesture with " << fingerCount << " fingers.\n";
            break;
    }
    if (sleepDuration > 0) {
        // std::cout << "[Sleep] Pausing for " << sleepDuration << " second(s).\n";
        sleep(sleepDuration); // sleep 적용
    }

    // 비활성 상태 자동 종료 처리
    if (keyboardActive &&
        std::chrono::steady_clock::now() - lastActivityTime > std::chrono::minutes(1)) {
        virtualKeyboard.hide();
        virtualMouse.activate();
        keyboardActive = false;
        std::cout << "Virtual keyboard auto-deactivated due to inactivity.\n";
    }
}

void GestureRecognition::resetInactivityTimer() {
    lastActivityTime = std::chrono::steady_clock::now();
}
