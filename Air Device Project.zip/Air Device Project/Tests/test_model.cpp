#include <torch/script.h>
#include <torch/torch.h>
#include <iostream>
#include <opencv2/opencv.hpp>
#include <filesystem>

int main() {
    // 모델 로드
    torch::jit::script::Module model;
    try {
        model = torch::jit::load(MODEL_PATH);
        std::cout << "모델 로드 성공: " << MODEL_PATH << std::endl;
    } catch (const c10::Error& e) {
        std::cerr << "모델 로드 실패: " << e.what() << std::endl;
        return -1;
    }

    // 테스트 데이터 로드
    std::string test_data_path = "../Archive/test/";
    std::vector<std::string> classes = {"0", "1", "2", "3", "4", "5"};
    int correct = 0, total = 0;

    for (const auto& cls : classes) {
        std::string class_path = test_data_path + cls;
        for (const auto& entry : std::filesystem::directory_iterator(class_path)) {
            cv::Mat img = cv::imread(entry.path().string(), cv::IMREAD_GRAYSCALE);
            if (img.empty()) {
                std::cerr << "이미지 로드 실패: " << entry.path() << std::endl;
                continue;
            }

            // 이미지 전처리
            cv::resize(img, img, cv::Size(64, 64));
            img.convertTo(img, CV_32F, 1.0 / 255.0); // 명시적 변환
            auto tensor_img = torch::from_blob(img.data, {1, 1, 64, 64}, torch::kFloat32).clone();

            try {
                // 모델 예측
                auto output = model.forward({tensor_img}).toTensor();
                auto prediction = output.argmax(1).item<int>();

                // 정확도 계산
                if (prediction == std::stoi(cls)) {
                    correct++;
                }
                total++;
            } catch (const c10::Error& e) {
                std::cerr << "예측 실패: " << e.what() << std::endl;
                continue;
            }
        }
    }

    // 정확도 계산 및 출력
    if (total > 0) {
        float accuracy = (static_cast<float>(correct) / total) * 100.0f;
        std::cout << "정확도: " << accuracy << "%" << std::endl;

        // 정확도 조건 확인
        // if (accuracy < 70.0f) {
        //     std::cerr << "테스트 정확도가 70% 미만입니다!" << std::endl;
        //     return -1;
        // }
    }

    return 0;
}
